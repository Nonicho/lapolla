#!/usr/bin/env python3
"""
Scraper de resultados de Quiniela - Lotería de la Provincia de Buenos Aires
Fuente oficial: https://loteria.gba.gob.ar/resultados

Extrae los resultados de los 5 sorteos diarios (La Previa, El Primero,
Matutina, Vespertina, Nocturna) y los guarda en resultados.json.
"""

import json
import re
import sys
from datetime import datetime
from pathlib import Path

import requests
from bs4 import BeautifulSoup

URL = "https://loteria.gba.gob.ar/resultados"
OUTPUT_FILE = Path(__file__).parent / "resultados.json"

# Nombres oficiales de los 5 sorteos diarios, en orden
SORTEOS = ["La Previa", "El Primero", "Matutina", "Vespertina", "Nocturna"]

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0 Safari/537.36"
    )
}


def fetch_html() -> str:
    """Descarga el HTML de la página de resultados."""
    resp = requests.get(URL, headers=HEADERS, timeout=20)
    resp.raise_for_status()
    return resp.text


def extract_sorteo(texto: str, nombre_sorteo: str) -> dict | None:
    """
    Busca un bloque de texto tipo:
    'Quiniela La Previa · 30/06/2026 · Sorteo N°1292 · 01 9383 · 02 8139 · ...'
    y lo parsea a un diccionario estructurado.
    """
    # Recorta el texto a partir del nombre del sorteo, hasta el próximo
    # nombre de sorteo (o el final del texto)
    patron_inicio = re.escape(f"Quiniela {nombre_sorteo}")
    match_inicio = re.search(patron_inicio, texto)
    if not match_inicio:
        return None

    resto = texto[match_inicio.end():]

    # Corta antes de que empiece el próximo sorteo, si aparece
    for otro in SORTEOS:
        if otro == nombre_sorteo:
            continue
        corte = re.search(re.escape(f"Quiniela {otro}"), resto)
        if corte:
            resto = resto[: corte.start()]

    # Fecha: dd/mm/aaaa
    fecha_match = re.search(r"(\d{2}/\d{2}/\d{4})", resto)
    fecha = fecha_match.group(1) if fecha_match else None

    # Número de sorteo
    sorteo_match = re.search(r"Sorteo N°\s*(\d+)", resto)
    numero_sorteo = sorteo_match.group(1) if sorteo_match else None

    # Pares "posición número" -> ej: "01 9383", "02 8139", etc.
    pares = re.findall(r"\b(\d{2})\s+(\d{3,4})\b", resto)
    extracto = {posicion: numero for posicion, numero in pares}

    if not fecha and not numero_sorteo and not extracto:
        return None

    return {
        "sorteo": nombre_sorteo,
        "fecha": fecha,
        "numero_sorteo": numero_sorteo,
        "extracto": extracto,
    }


def scrape() -> dict:
    html = fetch_html()
    soup = BeautifulSoup(html, "html.parser")
    texto = soup.get_text(separator=" ")
    # Normaliza espacios múltiples
    texto = re.sub(r"\s+", " ", texto)

    resultados = {}
    for nombre in SORTEOS:
        datos = extract_sorteo(texto, nombre)
        if datos:
            resultados[nombre] = datos

    return {
        "fuente": URL,
        "actualizado": datetime.utcnow().isoformat() + "Z",
        "sorteos": resultados,
    }


def main():
    try:
        data = scrape()
    except requests.RequestException as e:
        print(f"Error al conectar con la fuente: {e}", file=sys.stderr)
        sys.exit(1)

    if not data["sorteos"]:
        print(
            "Advertencia: no se pudo extraer ningún sorteo. "
            "El sitio puede haber cambiado su estructura.",
            file=sys.stderr,
        )
        # No sobrescribe el archivo anterior si no se encontró nada,
        # para no perder el último dato válido.
        sys.exit(2)

    OUTPUT_FILE.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"OK - resultados guardados en {OUTPUT_FILE}")
    print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
