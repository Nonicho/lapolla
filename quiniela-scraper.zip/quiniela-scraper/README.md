# Quiniela Scraper — Lotería de la Provincia de Buenos Aires

Bot en Python que scrapea los resultados oficiales de la Quiniela de la
Provincia de Buenos Aires desde la fuente oficial
(`https://loteria.gba.gob.ar/resultados`) y los guarda en `resultados.json`.

Pensado para alimentar a **La Polla** (u otro proyecto) leyendo ese JSON,
sin que el juego dependa directamente de scrapear nada.

## Cómo funciona

1. `scraper.py` descarga la página de resultados y extrae, para cada uno
   de los 5 sorteos diarios (La Previa, El Primero, Matutina, Vespertina,
   Nocturna): la fecha, el número de sorteo, y el extracto (posición →
   número).
2. Guarda todo en `resultados.json`.
3. Un workflow de **GitHub Actions** (`.github/workflows/scrape.yml`)
   corre el scraper automáticamente después de cada sorteo y sube el
   JSON actualizado al repo — sin que nadie tenga que ejecutarlo a mano.

## Uso local

```bash
pip install -r requirements.txt
python scraper.py
```

Esto genera/actualiza `resultados.json` en la misma carpeta.

## Formato de salida (`resultados.json`)

```json
{
  "fuente": "https://loteria.gba.gob.ar/resultados",
  "actualizado": "2026-07-01T18:20:00Z",
  "sorteos": {
    "La Previa": {
      "sorteo": "La Previa",
      "fecha": "30/06/2026",
      "numero_sorteo": "1292",
      "extracto": {
        "01": "9383",
        "02": "8139",
        "03": "9283"
      }
    }
  }
}
```

## Consumir los datos desde otro proyecto (ej. La Polla)

Si este repo es público, cualquier otro proyecto puede leer el JSON
directamente desde la URL "raw" de GitHub:

```
https://raw.githubusercontent.com/<tu-usuario>/<este-repo>/main/resultados.json
```

Ejemplo en JavaScript (para usar en `juego.html`):

```javascript
fetch("https://raw.githubusercontent.com/<tu-usuario>/<este-repo>/main/resultados.json")
  .then(res => res.json())
  .then(data => {
    console.log(data.sorteos["Nocturna"].extracto);
  });
```

## Notas importantes

- La fuente es el **sitio oficial de un organismo público**
  (Lotería de la Provincia de Buenos Aires) — son datos públicos, sin
  costo ni restricción de copia.
- El scraper busca patrones de texto flexibles (regex sobre el texto
  visible de la página), no depende de clases CSS específicas. Esto lo
  hace más resistente a cambios de diseño del sitio, aunque no infalible:
  si el sitio cambia mucho su estructura de texto, puede necesitar un
  ajuste puntual en `scraper.py`.
- Si el scraper no logra extraer ningún sorteo en una corrida, **no
  sobrescribe** `resultados.json` — así nunca se pierde el último dato
  válido por un fallo temporal del sitio.
